const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json()); // for parsing application/json

app.get('/:key(*)', (req, res) => {
  res.json(data.get(req.params.key));
});

app.put(':/key(*)', (req, res) => {
  data.set(req.params.key, req.body);
  res.json({
    status: "ok",
    payload: data.get(req.params.key)
  });
});

app.listen(port, () => console.log(`listening on port ${port}!`))