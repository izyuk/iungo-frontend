import React, {Component} from 'react';

class Tabs extends Component {
    render(){
        return(
            <div>

            </div>
        )
    }
}

export default Tabs;
