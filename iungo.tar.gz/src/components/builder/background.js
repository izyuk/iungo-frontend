import React, {Component} from 'react';
import axios from "axios";
import style from "./builder.less";

class Background extends Component {
    constructor(props) {
        super(props);
        this.selectColor = this.selectColor.bind(this);
        this.inputRef = React.createRef();
        this.state = {
            selectedFile: null
        }
    }

    selectColor(e) {
        console.log(e.target.value);
        this.inputRef.current.style.backgroundColor = e.target.value;
    }

    fileSelectedHandler = event => {
        this.setState({
            selectedFile: event.target.files[0]
        })
    };

    fileUploadHandler = () => {
        console.log(this.state.selectedFile);
        const fd = new FormData();
        fd.append('image', this.state.selectedFile, this.state.selectedFile.name);
        axios.post('http://localhost:3000/upload', fd)
            .then(res => {
                let el = document.querySelector(`.${this.props.style.imagePreview} img`);
                if (el) {
                    el.remove();
                }
                console.log(res);
                console.log('../../../src/uploads/' + res.data);
                // this.inputRef.current.insertAdjacentHTML('beforeend',
                //     '<img src='+require(+'../../../src/uploads/'+res.data)+'/>');
            });
    };

    render() {
        return (
            <div className={this.props.style.container} style={{display: this.props.active ? 'block': 'none'}}>
                <div className={this.props.style.imagePreview} ref={this.inputRef}>
                </div>
                <div className={this.props.style.row}>
                    <span className={this.props.style.descr}>
                        upload background img
                    </span>
                    <input type="file" onChange={this.fileSelectedHandler}/>
                    <button onClick={this.fileUploadHandler}>Upload</button>
                </div>
                <p className={this.props.style.hr}>or</p>
                <div className={this.props.style.row}>
                    <label htmlFor="sbc">Set backgr color</label>
                    <input type="text" onBlur={(e) => this.selectColor(e)} placeholder="Color code"/>
                </div>
            </div>
        )
    }
}

export default Background;
