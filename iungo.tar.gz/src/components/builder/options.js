import React, {Component} from 'react';
import Background from './background';
import LogoImage from './logo-image';
import style from './builder.less';

class Options extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedFile: null
        };
        this.Background = React.createRef();
        this.LogoImage = React.createRef();
        this.tabHandler = this.tabHandler.bind(this);
    }

    tabHandler(e) {
        console.log(e.target.getAttribute('data-id'));
        let item = e.target.getAttribute('data-id');

        // console.log(this[item].current.props.active);
        console.log(this[item].current.constructor.name);

        // this[item].current.props.active = !this[item].current.props.active;
    }


    render() {
        return (
            <div className={style.options}>
                <p className="name">Builder</p>
                <div className={style.wrap}>
                    <ul className={style.buttonsWrap}>
                        <li className={style.active}>Style</li>
                        <li>Content</li>
                        <li>Settings</li>
                    </ul>
                    <div className={style.dropdown}>
                        <div className="wrap">
                            <div className={style.head} onClick={this.tabHandler}>
                                <span>Background</span>
                            </div>
                            <Background style={style} active={true} ref={this.Background}/>
                        </div>
                        <div className="wrap">
                            <div className={style.head} onClick={this.tabHandler}>
                                <span>Logo Image</span>
                            </div>
                            <LogoImage style={style} active={false} ref={this.LogoImage}/>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    // componentDidMount() {
    //     this.inputRef.current.focus();
    // }
}

export default Options;
