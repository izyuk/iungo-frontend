export default function (state = null, action) {
    switch (/*action.type*/ '1') {
        case '1':
            return true;
    }
}
